package br.com.edgarneto.medicalconsult;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicalconsultApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedicalconsultApplication.class, args);
	}

}
